import Image from "next/image";
import BuyButton from "./components/BuyButton";

export default function Home() {
  return (
    <main className="min-h-screen bg-navy text-cream">
      {/* Nav */}
      <header className="sticky top-0 z-20 border-b border-white/5 bg-navy/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <span className="font-display text-lg tracking-wide text-cream">
            Tap<span className="text-gold">reviews</span>
          </span>
          <a
            href="#order"
            className="focus-ring rounded-full border border-gold/50 px-5 py-2 text-xs font-semibold uppercase tracking-widest text-gold transition hover:bg-gold hover:text-navy"
          >
            Order
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-16 px-6 py-20 md:grid-cols-2 md:py-28">
          <div>
            <p className="eyebrow text-gold">NFC Google Review Card</p>
            <h1 className="mt-5 font-display text-4xl leading-[1.1] text-cream sm:text-5xl md:text-[3.2rem]">
              Turn every visit into a five-star review.
            </h1>
            <p className="mt-6 max-w-md text-base leading-relaxed text-muted">
              One tap of a phone against the card opens your Google review
              page directly — no app, no typing, no searching. Just an
              honest ask, made effortless for your guests.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-6">
              <BuyButton />
              <div>
                <p className="font-display text-2xl text-cream">€24,95</p>
                <p className="text-xs text-muted">Free shipping in NL</p>
              </div>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-md">
            <div className="pointer-events-none absolute -right-6 top-1/3 h-24 w-24">
              <span className="tap-ring absolute inset-0" />
              <span className="tap-ring delay-1 absolute inset-0" />
              <span className="tap-ring delay-2 absolute inset-0" />
            </div>
            <div className="overflow-hidden rounded-2xl border border-gold/20 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.6)]">
              <Image
                src="/product.png"
                alt="Tapreviews NFC card on a wooden stand next to a phone showing a five-star review screen"
                width={900}
                height={900}
                priority
                className="h-auto w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-6">
        <div className="gold-rule" />
      </div>

      {/* How it works */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <p className="eyebrow text-gold">How it works</p>
        <h2 className="mt-4 max-w-lg font-display text-3xl text-cream">
          Three steps, a few seconds, no friction.
        </h2>
        <div className="mt-14 grid grid-cols-1 gap-10 md:grid-cols-3">
          {[
            {
              n: "01",
              title: "Place the card",
              body: "Set the card and its wooden stand on the counter, table, or checkout desk where guests naturally pause.",
            },
            {
              n: "02",
              title: "Guest taps their phone",
              body: "No app or camera needed — a single tap opens your Google review page on their screen instantly.",
            },
            {
              n: "03",
              title: "The review is posted",
              body: "They rate and write their thoughts right there, in seconds, while the experience is still fresh.",
            },
          ].map((step) => (
            <div key={step.n} className="rounded-xl border border-white/5 bg-navy-light p-8">
              <p className="font-display text-3xl text-gold/80">{step.n}</p>
              <h3 className="mt-4 font-display text-xl text-cream">
                {step.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                {step.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-6">
        <div className="gold-rule" />
      </div>

      {/* Product / order */}
      <section id="order" className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid grid-cols-1 gap-14 md:grid-cols-2">
          <div>
            <p className="eyebrow text-gold">The set</p>
            <h2 className="mt-4 font-display text-3xl text-cream">
              NFC Google Review Card &amp; stand
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-muted">
              Every order includes the NFC review card and its solid wooden
              display stand as one set — ready to place on a counter or
              table the moment it arrives.
            </p>
            <ul className="mt-8 space-y-3 text-sm text-cream/90">
              <li className="flex gap-3">
                <span className="text-gold">—</span> NFC card, pre-programmed
                with your Google review link
              </li>
              <li className="flex gap-3">
                <span className="text-gold">—</span> Solid wooden display
                stand included
              </li>
              <li className="flex gap-3">
                <span className="text-gold">—</span> Works with any modern
                smartphone, no app required
              </li>
              <li className="flex gap-3">
                <span className="text-gold">—</span> Free shipping within
                the Netherlands
              </li>
            </ul>
          </div>

          <div className="rounded-2xl border border-gold/20 bg-navy-light p-10">
            <p className="eyebrow text-gold">Price</p>
            <p className="mt-4 font-display text-5xl text-cream">€24,95</p>
            <p className="mt-2 text-sm text-muted">
              One-time purchase · card + stand · free shipping
            </p>
            <div className="mt-10">
              <BuyButton className="w-full" />
            </div>
            <p className="mt-6 text-xs text-muted">
              Secure checkout via Stripe. Ships within the Netherlands, with
              Belgium coming soon.
            </p>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-6">
        <div className="gold-rule" />
      </div>

      {/* Reviews */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <p className="eyebrow text-gold">From our customers</p>
        <h2 className="mt-4 max-w-lg font-display text-3xl text-cream">
          Reviews will appear here soon.
        </h2>
        <div className="mt-10 rounded-xl border border-dashed border-gold/25 bg-navy-light/60 p-10 text-center">
          <p className="mx-auto max-w-md text-sm leading-relaxed text-muted">
            We're keeping this space empty until real customers have real
            things to say. Be one of the first to try Tapreviews, and your
            review could be featured right here.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-3 px-6 py-10 text-center text-xs text-muted md:flex-row md:justify-between md:text-left">
          <span className="font-display text-sm text-cream">
            Tap<span className="text-gold">reviews</span>
          </span>
          <p>
            Questions? Reach us at{" "}
            <a
              href="mailto:info@tapreviews.nl"
              className="focus-ring text-gold hover:text-gold-light"
            >
              info@tapreviews.nl
            </a>
          </p>
          <p>© {new Date().getFullYear()} Tapreviews</p>
        </div>
      </footer>
    </main>
  );
}
