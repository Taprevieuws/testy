import Link from "next/link";

export default function CancelPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-navy px-6 text-center text-cream">
      <p className="eyebrow text-gold">Checkout cancelled</p>
      <h1 className="mt-5 max-w-md font-display text-3xl text-cream">
        No worries — nothing was charged.
      </h1>
      <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
        You can pick up right where you left off whenever you're ready to
        order.
      </p>
      <Link
        href="/#order"
        className="focus-ring mt-10 rounded-full bg-gold px-6 py-3 text-xs font-semibold uppercase tracking-widest text-navy transition hover:bg-gold-light"
      >
        Return to order
      </Link>
    </main>
  );
}
