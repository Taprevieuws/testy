"use client";

import { useState } from "react";

export default function BuyButton({ className = "" }: { className?: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleClick() {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/checkout", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.url) {
        throw new Error(data.error || "Something went wrong");
      }
      window.location.href = data.url;
    } catch (err) {
      setError(
        "Checkout kon niet gestart worden. Probeer het opnieuw of neem contact op."
      );
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        onClick={handleClick}
        disabled={loading}
        className={`focus-ring inline-flex items-center justify-center rounded-full bg-gold px-8 py-4 font-sans text-sm font-semibold uppercase tracking-widest text-navy transition hover:bg-gold-light disabled:cursor-not-allowed disabled:opacity-70 ${className}`}
      >
        {loading ? "Een moment..." : "Order now — free shipping"}
      </button>
      {error && (
        <p className="mt-3 text-sm text-red-300" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
