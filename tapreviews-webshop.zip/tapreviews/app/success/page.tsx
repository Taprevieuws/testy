import Link from "next/link";

export default function SuccessPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-navy px-6 text-center text-cream">
      <p className="eyebrow text-gold">Order confirmed</p>
      <h1 className="mt-5 max-w-md font-display text-3xl text-cream">
        Thank you — your Tapreviews card is on its way.
      </h1>
      <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
        You'll receive a confirmation email shortly with your order details.
        Your card will be programmed with your Google review link before it
        ships.
      </p>
      <Link
        href="/"
        className="focus-ring mt-10 rounded-full border border-gold/50 px-6 py-3 text-xs font-semibold uppercase tracking-widest text-gold transition hover:bg-gold hover:text-navy"
      >
        Back to home
      </Link>
    </main>
  );
}
